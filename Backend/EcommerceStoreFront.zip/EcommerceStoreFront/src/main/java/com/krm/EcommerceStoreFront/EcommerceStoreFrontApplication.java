package com.krm.EcommerceStoreFront;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceStoreFrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceStoreFrontApplication.class, args);
	}

}
