package com.krm.EcommerceStoreFront;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceStoreFrontApplicationTests {

	@Test
	void contextLoads() {
	}

}
